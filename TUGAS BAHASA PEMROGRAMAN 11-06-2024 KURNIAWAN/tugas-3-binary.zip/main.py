'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print("Nama: KURNIAWAN")
print("Nim: 20230801054")
print("Tanggal : 11-06-2024")
print("TUGAS KE 3")
print()

def input_transaksi(transaksi_list):
    tanggal = input("TANGGAL (tanggal-bulan-tahun): ")
    keterangan = input("KETERANGAN: ")
    jenis = input("JENIS (Pemasukan/Pengeluaran): ").strip().lower()
    jumlah = float(input("JUMLAH: "))
    transaksi_list.append({"TANGGAL": tanggal, "KETERANGAN": keterangan, "JENIS": jenis, "JUMLAH": jumlah})

def tampilkan_semua_transaksi(transaksi_list):
    print("\nDATA TRANSAKSI")
    print(f"{'NO':<5}{'TANGGAL':<15}{'KETERANGAN':<20}{'JENIS':<15}{'JUMLAH':<10}")
    print("-" * 70)
    
    for i, transaksi in enumerate(transaksi_list):
        print(f"{i + 1:<5}{transaksi['TANGGAL']:<15}{transaksi['KETERANGAN']:<20}{transaksi['JENIS']:<15}{transaksi['JUMLAH']:<10.2f}")

def hitung_total_pemasukan(transaksi_list):
    return sum(transaksi['JUMLAH'] for transaksi in transaksi_list if transaksi['JENIS'] == 'pemasukan')

def hitung_total_pengeluaran(transaksi_list):
    return sum(transaksi['JUMLAH'] for transaksi in transaksi_list if transaksi['JENIS'] == 'pengeluaran')

def tampilkan_total_pemasukan(transaksi_list):
    total_pemasukan = hitung_total_pemasukan(transaksi_list)
    print(f"\nTOTAL PEMASUKAN: {total_pemasukan:.2f}")

def tampilkan_total_pengeluaran(transaksi_list):
    total_pengeluaran = hitung_total_pengeluaran(transaksi_list)
    print(f"\nTOTAL PENGELUARAN: {total_pengeluaran:.2f}")

def tampilkan_saldo_akhir(transaksi_list):
    total_pemasukan = hitung_total_pemasukan(transaksi_list)
    total_pengeluaran = hitung_total_pengeluaran(transaksi_list)
    saldo_akhir = total_pemasukan - total_pengeluaran
    print(f"\nSALDO AKHIR: {saldo_akhir:.2f}")

def main():
    transaksi_list = []

    menu_actions = {
        1: lambda: input_transaksi(transaksi_list),
        2: lambda: tampilkan_semua_transaksi(transaksi_list),
        3: lambda: tampilkan_total_pemasukan(transaksi_list),
        4: lambda: tampilkan_total_pengeluaran(transaksi_list),
        5: lambda: tampilkan_saldo_akhir(transaksi_list),
        6: lambda: exit("Keluar dari program ")
    }

    while True:
        print("\nMENU:")
        print("1. Input Transaksi")
        print("2. Tampilkan Semua Transaksi")
        print("3. Hitung dan Tampilkan Total Pemasukan")
        print("4. Hitung dan Tampilkan Total Pengeluaran")
        print("5. Hitung dan Tampilkan Saldo Akhir")
        print("6. Keluar")

        choice = int(input("\nPILIHAN: "))
        action = menu_actions.get(choice, lambda: print("Pilihan tidak valid, silakan coba lagi "))
        action()

if __name__ == "__main__":
    main()