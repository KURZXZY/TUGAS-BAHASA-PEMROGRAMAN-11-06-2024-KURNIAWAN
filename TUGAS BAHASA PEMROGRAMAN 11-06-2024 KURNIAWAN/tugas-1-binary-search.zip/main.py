'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
print("Nama: KURNIAWAN")
print("Nim: 20230801054")
print("Tanggal : 11-06-2024")
print("TUGAS KE 3")
print()

def binary_search(arr, target):
    
    left, right = 0, len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        print(f"Memeriksa indeks tengah {mid}: nilai {arr[mid][0]}")
        
        if arr[mid][0] == target:
            return mid
        elif arr[mid][0] < target:
            left = mid + 1
        else:
            right = mid - 1
    
    return -1

# Fungsi untuk mendapatkan input pengguna dan memastikan daftar terurut
def get_user_input():
    try:
        n = int(input("Masukkan jumlah motor yang ingin dimasukkan: "))
        arr = []
        for _ in range(n):
            motor = input("Masukkan merek motor: ")
            tahun = int(input("Masukkan tahun produksi: "))
            arr.append((motor, tahun))
        
        # Mengurutkan daftar berdasarkan merek motor
        arr.sort(key=lambda x: x[0])
        print(f"Daftar yang diurutkan: {arr}")
        
        target = input("Masukkan merek motor yang ingin dicari: ")
        return arr, target
    except ValueError:
        print("Input tidak valid, pastikan untuk memasukkan bilangan bulat untuk tahun produksi.")
        return get_user_input()

# Eksekusi utama
if __name__ == "__main__":
    arr, target = get_user_input()
    result = binary_search(arr, target)

    if result != -1:
        print(f"Merek {target} ditemukan pada indeks {result} dengan tahun produksi {arr[result][1]}")
    else:
        print("Merek tidak ditemukan")
