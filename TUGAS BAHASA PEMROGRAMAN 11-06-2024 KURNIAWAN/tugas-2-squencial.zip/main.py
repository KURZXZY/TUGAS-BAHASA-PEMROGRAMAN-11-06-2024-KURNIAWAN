'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''

print("Nama: KURNIAWAN")
print("Nim: 20230801054")
print("Tanggal : 11-06-2024")
print("TUGAS KE 3")
print()

import time

def pencarian_sekuensial(arr, target):

    indeks = []
    waktu_mulai = time.time()
    
    print(f"Memulai pencarian untuk {target} dalam {arr}")
    for index, value in enumerate(arr):
        print(f"Memeriksa indeks {index}: nilai {value}")
        if value == target:
            print(f"Ditemukan {target} pada indeks {index}")
            indeks.append(index)
    
    waktu_selesai = time.time()
    waktu_pencarian = waktu_selesai - waktu_mulai
    print(f"Pencarian selesai dalam {waktu_pencarian:.4f} detik")

    if indeks:
        return indeks
    else:
        return "Elemen tidak ditemukan"

# Fungsi untuk mendapatkan input pengguna
def mendapatkan_input_pengguna():
    try:
        arr = list(map(int, input("Masukkan daftar bilangan (dipisahkan dengan spasi): ").split()))
        target = int(input("Masukkan nilai target yang ingin dicari: "))
        return arr, target
    except ValueError:
        print("Input tidak valid, pastikan untuk memasukkan bilangan bulat.")
        return mendapatkan_input_pengguna()

# Eksekusi utama
if __name__ == "__main__":
    arr, target = mendapatkan_input_pengguna()
    hasil = pencarian_sekuensial(arr, target)

    if isinstance(hasil, list):
        print(f"Elemen {target} ditemukan pada indeks {hasil}")
    else:
        print(hasil)

